package test;

import static org.junit.Assert.*;

import org.junit.Test;

import main.Planet;

/**
 *  Tests the Planet constructor.
 */
public class TestPlanetConstructor {

    @Test
    public void checkConstructor() {
      System.out.println("Checking Planet constructor...");

      double xxPos = 1.0, yyPos = 2.0, xxVel = 3.0, yyVel = 4.0, mass = 5.0;

      String imgFileName = "jupiter.gif";

      Planet p = new Planet(xxPos, yyPos, xxVel, yyVel, mass, imgFileName);

      assertEquals("xxPos = 1.0", xxPos, p.getxPos(),0.001);
      assertEquals("yyPos = 2.0", yyPos, p.getyPos(),0.001);
      assertEquals("xxVel = 3.0", xxVel, p.getxVel(),0.001);
      assertEquals("yyVel = 4.0", yyVel, p.getyVel(),0.001);
      assertEquals("mass = 5.0", mass, p.getMass(),0.001);
      assertEquals(imgFileName, imgFileName, p.getImgFileName());
  }
}
